import OutLayout from "../components/layouts/OutLayout";
import Cart from "../components/ui/Cart";
export default function CartPage() {
  return (
    <OutLayout>
      <Cart />
    </OutLayout>
  );
}
